package projet.comsuper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComsuperApplicationTests {

	@Test
	void contextLoads() {
	}

}
