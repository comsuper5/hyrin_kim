package projet.comsuper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComsuperApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComsuperApplication.class, args);
	}

}
