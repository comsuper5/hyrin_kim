document.addEventListener("DOMContentLoaded", function () {
    // 로컬스토리지에서 저장된 게시글 데이터 가져오기
    const storeditemss = JSON.parse(localStorage.getItem("itemss")) || [];
  
    // 현재 페이지 URL에서 게시글 인덱스 값을 가져오기
    const urlParams = new URLSearchParams(window.location.search);
    const itemsIndex = parseInt(urlParams.get("index"));
  
    // 해당 인덱스에 해당하는 게시글 데이터 가져오기
    const items = storeditemss[itemsIndex];
  
    // 게시글 데이터가 존재하면 표시하기
    if (items) {
      // 타이틀 입력 필드 표시
      const titleInput = document.getElementById("items-title");
      titleInput.value = items.title;
  
      // 내용 입력 필드 표시
      const contentInput = document.getElementById("items-content");
      contentInput.value = items.content;
  
      // 수정 완료 버튼 동작
      const saveBtn = document.getElementById("notice-modify-btn");
      saveBtn.addEventListener("click", function () {
        // 수정된 타이틀과 내용 가져오기
        const modifiedTitle = titleInput.value;
        const modifiedContent = contentInput.value;
  
        // 현재 게시글 데이터 업데이트
        storeditemss[itemsIndex] = {
          ...items,
          title: modifiedTitle,
          content: modifiedContent,
        };
  
        // 업데이트된 게시글 데이터를 로컬스토리지에 저장
        localStorage.setItem("itemss", JSON.stringify(storeditemss));
  
        // 수정된 게시글 확인 페이지로 이동
        window.location.href = "notice-content.html?index=" + itemsIndex;
      });
  
      // 취소 버튼 동작
      const cancelBtn = document.getElementById("notice-cancle-btn");
      cancelBtn.addEventListener("click", function () {
        // 수정 취소 시 이전 게시글 확인 페이지로 이동
        window.location.href = "notice-list.html?index=" + itemsIndex;
      });
    }
  });